**Before continuing** make sure you have a working Salt installation by
following the :ref:`installation` and the
:ref:`configuration <configuring-salt>` instructions.

.. admonition:: Stuck?

    There are many ways to :ref:`get help from the Salt community
    <salt-community>` including our
    `mailing list <https://groups.google.com/forum/#!forum/salt-users>`_
    and our `IRC channel <http://webchat.freenode.net/?channels=salt>`_ #salt.