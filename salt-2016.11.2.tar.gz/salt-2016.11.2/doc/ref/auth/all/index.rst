.. _all-salt.auth:

============
auth modules
============

.. currentmodule:: salt.auth

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    auto
    django
    keystone
    ldap
    mysql
    pam
    pki
    rest
    sharedsecret
    stormpath
    yubico
