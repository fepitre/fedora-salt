===========================
salt.cloud.clouds.qingcloud
===========================

.. automodule:: salt.cloud.clouds.qingcloud
    :members: