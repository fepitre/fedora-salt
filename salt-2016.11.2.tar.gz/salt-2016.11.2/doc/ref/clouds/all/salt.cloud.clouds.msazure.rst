=========================
salt.cloud.clouds.msazure
=========================

.. automodule:: salt.cloud.clouds.msazure
    :members: