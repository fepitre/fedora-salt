.. _all-salt.clouds:

===============================
Full list of Salt Cloud modules
===============================

.. currentmodule:: salt.cloud.clouds

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    aliyun
    azurearm
    cloudstack
    digital_ocean
    dimensiondata
    ec2
    gce
    gogrid
    joyent
    linode
    lxc
    msazure
    nova
    opennebula
    openstack
    parallels
    proxmox
    pyrax
    qingcloud
    rackspace
    saltify
    scaleway
    softlayer
    softlayer_hw
    virtualbox
    vmware
