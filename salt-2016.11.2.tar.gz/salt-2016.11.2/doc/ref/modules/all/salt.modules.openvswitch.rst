salt.modules.openvswitch module
===============================

.. automodule:: salt.modules.openvswitch
    :members:
