======================
salt.modules.debian_ip
======================

.. automodule:: salt.modules.debian_ip
    :members: