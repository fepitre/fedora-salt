salt.modules.inspectlib.kiwiproc module
=======================================

.. automodule:: salt.modules.inspectlib.kiwiproc
    :members:
    :undoc-members:
