==========================
salt.modules.cassandra_cql
==========================

.. automodule:: salt.modules.cassandra_cql
    :members: