===================
salt.modules.pillar
===================

.. automodule:: salt.modules.pillar
    :members:
    :exclude-members: data