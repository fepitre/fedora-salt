salt.modules.boto_apigateway module
===================================

.. automodule:: salt.modules.boto_apigateway
    :members:
