salt.modules.jenkins module
===========================

.. automodule:: salt.modules.jenkins
    :members:
