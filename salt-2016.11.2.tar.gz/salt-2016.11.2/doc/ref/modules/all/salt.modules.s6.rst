salt.modules.s6 module
======================

.. automodule:: salt.modules.s6
    :members:
