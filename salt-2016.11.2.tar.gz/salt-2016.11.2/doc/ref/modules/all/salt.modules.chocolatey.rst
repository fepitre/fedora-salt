=======================
salt.modules.chocolatey
=======================

.. automodule:: salt.modules.chocolatey
    :members: