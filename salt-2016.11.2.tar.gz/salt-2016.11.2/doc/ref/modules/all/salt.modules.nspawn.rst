===================
salt.modules.nspawn
===================

.. automodule:: salt.modules.nspawn
    :members:
    :exclude-members: cp, destroy, list_, pull_docker, restart, stop
