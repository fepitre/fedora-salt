=================
salt.modules.cpan
=================

.. automodule:: salt.modules.cpan
    :members:
