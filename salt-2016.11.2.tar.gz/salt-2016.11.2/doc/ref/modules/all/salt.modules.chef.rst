=================
salt.modules.chef
=================

.. automodule:: salt.modules.chef
    :members: