=========================
salt.modules.smartos_virt
=========================

.. automodule:: salt.modules.smartos_virt
    :members:
