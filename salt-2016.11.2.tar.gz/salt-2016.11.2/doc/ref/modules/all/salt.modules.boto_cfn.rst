=====================
salt.modules.boto_cfn
=====================

.. automodule:: salt.modules.boto_cfn
    :members:
