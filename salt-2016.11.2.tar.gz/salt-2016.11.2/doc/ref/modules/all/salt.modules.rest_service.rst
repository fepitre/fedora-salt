=========================
salt.modules.rest_service
=========================

.. automodule:: salt.modules.rest_service
    :members: