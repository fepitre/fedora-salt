=====================
salt.modules.rpmbuild
=====================

.. automodule:: salt.modules.rpmbuild
    :members:
