salt.modules.mac_desktop module
===============================

.. automodule:: salt.modules.mac_desktop
    :members:
