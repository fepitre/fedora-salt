===========================
salt.modules.portage_config
===========================

.. automodule:: salt.modules.portage_config
    :members: