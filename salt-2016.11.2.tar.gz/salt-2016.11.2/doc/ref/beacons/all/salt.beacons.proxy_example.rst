salt.beacons.proxy_example module
=================================

.. automodule:: salt.beacons.proxy_example
    :members:
